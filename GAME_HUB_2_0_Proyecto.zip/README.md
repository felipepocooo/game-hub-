# GAME HUB 2.0
Proyecto Android WebView. Incluye ruleta, equipos, cronómetro, marcador, memoria, quiz, tres en raya, XP, niveles, logros, efectos de sonido, temas y un icono personalizado.

Compilar en GitHub Actions con Java 17 y Gradle 8.7: `gradle assembleDebug`. El archivo resultante es `app/build/outputs/apk/debug/app-debug.apk`.

La fuente pixel y el fondo remoto pueden requerir conexión; la app mantiene alternativas locales si no cargan.
